<tr>
  
    <th scope="row">{{$user['id']}}</th>
    <td>{{$user['name']}}</td>
    <td>Otto</td>
    <td>Otto</td>
  </tr>